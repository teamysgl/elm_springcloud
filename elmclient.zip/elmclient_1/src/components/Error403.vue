<template>
  <div class="wrapper">
    <img src="../assets/图片1.jpg"><br>
    <router-link to="/index">返回重试</router-link>
  </div>
</template>

<script>
</script>

<style scoped>
  .wrapper{
    text-align: center;
  }
  .wrapper img{
    margin: 120px 0 20px;
  }
  .wrapper a{
    color: #0097EF;
  }
</style>