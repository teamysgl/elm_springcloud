module.exports = {
	devServer: {
		port:8082
	}
}